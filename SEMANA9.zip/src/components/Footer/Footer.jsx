import './Footer.css'

function Footer() {
  return (
    <footer className="footer" id="contacto">
      <div className="container footer__inner">
        <div className="footer__brand">
          <a className="footer__logo" href="#inicio">
            <span aria-hidden="true">✦</span> Cine Lumière
          </a>
          <p className="footer__about">
            Una sala independiente dedicada al cine clásico y de autor. Pantalla
            gigante, sonido envolvente y la mejor selección de la semana.
          </p>
          <ul className="footer__social" aria-label="Redes sociales">
            <li>
              <a href="https://instagram.com" target="_blank" rel="noreferrer">
                Instagram
              </a>
            </li>
            <li>
              <a href="https://facebook.com" target="_blank" rel="noreferrer">
                Facebook
              </a>
            </li>
            <li>
              <a href="https://youtube.com" target="_blank" rel="noreferrer">
                YouTube
              </a>
            </li>
          </ul>
        </div>

        <div className="footer__column">
          <h2 className="footer__heading">Contacto</h2>
          <ul className="footer__list">
            <li>
              <span>Dirección</span>
              Av. Central 245, Plaza Lumière
            </li>
            <li>
              <span>Teléfono</span>
              <a href="tel:+51987654321">+51 987 654 321</a>
            </li>
            <li>
              <span>Correo</span>
              <a href="mailto:hola@cinelumiere.pe">hola@cinelumiere.pe</a>
            </li>
          </ul>
        </div>

        <div className="footer__column">
          <h2 className="footer__heading">Horarios</h2>
          <ul className="footer__list">
            <li>
              <span>Lunes a jueves</span>
              12:00 – 23:00
            </li>
            <li>
              <span>Viernes a domingo</span>
              11:00 – 01:00
            </li>
            <li>
              <span>Taquilla</span>
              Abre 30 minutos antes
            </li>
          </ul>
        </div>
      </div>

      <div className="container footer__bottom">
        <p>© 2026 Cine Lumière. Todos los derechos reservados.</p>
        <p>Laboratorio Semana 9 · ReactJS</p>
      </div>
    </footer>
  )
}

export default Footer
