import './Hero.css'

function Hero({ movie }) {
  if (!movie) return null

  return (
    <section className="hero" id="inicio" aria-labelledby="hero-title">
      <div className="hero__inner container">
        <div className="hero__content">
          <p className="eyebrow">
            <span className="eyebrow__dot" aria-hidden="true" />
            Película destacada
          </p>

          <h1 className="hero__title" id="hero-title">
            {movie.title}
          </h1>

          <ul className="hero__meta">
            <li className="hero__rating">{movie.ageRating}</li>
            <li>{movie.genres.join(' · ')}</li>
            <li>{movie.duration}</li>
            <li className="hero__score">
              <span aria-hidden="true">★</span> {movie.score.toFixed(1)}
            </li>
          </ul>

          <p className="hero__synopsis">{movie.synopsis}</p>

          <div className="hero__schedules">
            <p className="hero__schedules-label">Funciones de hoy</p>
            <ul className="hero__schedule-list">
              {movie.schedules.map((time) => (
                <li className="chip chip--strong" key={time}>
                  {time}
                </li>
              ))}
            </ul>
          </div>

          <div className="hero__actions">
            <a className="button button--primary" href="#cartelera">
              Comprar entradas
            </a>
            <a className="button button--ghost" href="#cartelera">
              Ver cartelera
            </a>
          </div>
        </div>

        <div className="hero__media">
          <div className="hero__poster">
            <img
              src={movie.poster}
              alt={`Póster de ${movie.title}`}
              width="600"
              height="900"
            />
            <span className="hero__badge">Estreno</span>
          </div>
          <p className="hero__caption">Sala 1 · Formato IMAX · Dolby Atmos</p>
        </div>
      </div>
    </section>
  )
}

export default Hero
