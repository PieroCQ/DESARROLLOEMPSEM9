import './MovieCard.css'

function MovieCard({ movie }) {
  const { title, poster, synopsis, ageRating, score, duration, genres, schedules } =
    movie

  return (
    <article className="movie-card">
      <div className="movie-card__media">
        <img
          src={poster}
          alt={`Póster de ${title}`}
          width="600"
          height="900"
          loading="lazy"
        />
        <span className="movie-card__rating" title="Clasificación por edad">
          {ageRating}
        </span>
        <span
          className="movie-card__score"
          aria-label={`Valoración ${score} de 10`}
        >
          <span aria-hidden="true">★</span> {score.toFixed(1)}
        </span>
      </div>

      <div className="movie-card__body">
        <p className="movie-card__genres">{genres.join(' · ')}</p>
        <h3 className="movie-card__title">{title}</h3>
        <p className="movie-card__synopsis">{synopsis}</p>

        <div className="movie-card__footer">
          <p className="movie-card__duration">{duration}</p>
          <ul
            className="movie-card__schedules"
            aria-label={`Horarios de ${title}`}
          >
            {schedules.map((time) => (
              <li className="chip" key={time}>
                {time}
              </li>
            ))}
          </ul>
        </div>

        <a className="movie-card__link" href="#inicio">
          Reservar entrada
          <span aria-hidden="true">→</span>
        </a>
      </div>
    </article>
  )
}

export default MovieCard
