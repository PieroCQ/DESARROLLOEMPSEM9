import './Header.css'

const navigation = [
  { label: 'Cartelera', href: '#cartelera' },
  { label: 'Estrenos', href: '#cartelera' },
  { label: 'Promociones', href: '#contacto' },
  { label: 'Contacto', href: '#contacto' },
]

function Header() {
  return (
    <header className="header">
      <div className="header__inner container">
        <a className="header__brand" href="#inicio">
          <span className="header__mark" aria-hidden="true">
            ✦
          </span>
          <span className="header__name">
            Cine <strong>Lumière</strong>
          </span>
        </a>

        <nav className="header__nav" aria-label="Navegación principal">
          <ul className="header__list">
            {navigation.map((item) => (
              <li key={item.label}>
                <a className="header__link" href={item.href}>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <a className="button button--ghost header__cta" href="#cartelera">
          Comprar entradas
        </a>
      </div>
    </header>
  )
}

export default Header
