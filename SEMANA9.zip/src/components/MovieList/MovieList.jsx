import MovieCard from '../MovieCard/MovieCard'
import './MovieList.css'

function MovieList({ movies }) {
  return (
    <section className="movie-list" id="cartelera" aria-labelledby="cartelera-title">
      <div className="container">
        <header className="movie-list__header">
          <div>
            <p className="eyebrow">
              <span className="eyebrow__dot" aria-hidden="true" />
              En cartelera
            </p>
            <h2 className="movie-list__title" id="cartelera-title">
              Películas de esta semana
            </h2>
            <p className="movie-list__subtitle">
              Elige tu función y reserva en línea. Todas las salas cuentan con
              sonido Dolby Atmos.
            </p>
          </div>
          <p className="movie-list__count">
            <strong>{movies.length}</strong> películas en sala
          </p>
        </header>

        {movies.length === 0 ? (
          <p className="movie-list__empty">
            No hay películas disponibles en este momento.
          </p>
        ) : (
          <ul className="movie-list__grid">
            {movies.map((movie) => (
              <li className="movie-list__item" key={movie.id}>
                <MovieCard movie={movie} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  )
}

export default MovieList
