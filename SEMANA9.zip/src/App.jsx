import Header from './components/Header/Header'
import Hero from './components/Hero/Hero'
import MovieList from './components/MovieList/MovieList'
import Footer from './components/Footer/Footer'
import { featuredMovie, movies } from './data/movies'

function App() {
  return (
    <div className="app">
      <Header />

      <main className="app__main">
        <Hero movie={featuredMovie} />
        <MovieList movies={movies} />
      </main>

      <Footer />
    </div>
  )
}

export default App
