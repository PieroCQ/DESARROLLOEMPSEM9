/**
 * Billboard data. Each movie is a plain object so components only receive
 * what they need through props and never import the data themselves.
 */
export const movies = [
  {
    id: 'dune-part-two',
    title: 'Dune: Parte Dos',
    poster: '/posters/dune-part-two.svg',
    synopsis:
      'Paul Atreides se une a los Fremen para vengar a su familia y evitar un futuro terrible que solo él puede ver.',
    ageRating: '+14',
    score: 8.7,
    duration: '2 h 46 min',
    genres: ['Ciencia ficción', 'Aventura'],
    schedules: ['14:30', '17:45', '21:00'],
    featured: true,
  },
  {
    id: 'oppenheimer',
    title: 'Oppenheimer',
    poster: '/posters/oppenheimer.svg',
    synopsis:
      'La historia del científico que lideró el Proyecto Manhattan y cambió el mundo para siempre.',
    ageRating: '+16',
    score: 8.5,
    duration: '3 h 00 min',
    genres: ['Drama', 'Histórico'],
    schedules: ['15:00', '18:30', '21:30'],
  },
  {
    id: 'interstellar',
    title: 'Interstellar',
    poster: '/posters/interstellar.svg',
    synopsis:
      'Un grupo de exploradores atraviesa un agujero de gusano para encontrar un nuevo hogar para la humanidad.',
    ageRating: '+12',
    score: 8.6,
    duration: '2 h 49 min',
    genres: ['Ciencia ficción', 'Drama'],
    schedules: ['13:15', '16:40', '20:05'],
  },
  {
    id: 'the-godfather',
    title: 'El Padrino',
    poster: '/posters/the-godfather.svg',
    synopsis:
      'El patriarca de una dinastía del crimen organizado decide quién continuará su legado.',
    ageRating: '+18',
    score: 9.2,
    duration: '2 h 55 min',
    genres: ['Drama', 'Crimen'],
    schedules: ['16:00', '20:30'],
  },
  {
    id: 'pulp-fiction',
    title: 'Pulp Fiction',
    poster: '/posters/pulp-fiction.svg',
    synopsis:
      'Historias entrelazadas de gánsteres, boxeadores y ladrones en un Los Ángeles inolvidable.',
    ageRating: '+18',
    score: 8.9,
    duration: '2 h 34 min',
    genres: ['Crimen', 'Comedia negra'],
    schedules: ['17:10', '21:15'],
  },
  {
    id: 'spider-verse',
    title: 'Spider-Man: Un nuevo universo',
    poster: '/posters/spider-verse.svg',
    synopsis:
      'Miles Morales descubre que no está solo: otros Spider-Man llegan desde dimensiones paralelas.',
    ageRating: 'TP',
    score: 8.4,
    duration: '1 h 57 min',
    genres: ['Animación', 'Acción'],
    schedules: ['12:00', '14:50', '17:40'],
  },
  {
    id: 'barbie',
    title: 'Barbie',
    poster: '/posters/barbie.svg',
    synopsis:
      'Barbie y Ken viven en Barbieland hasta que un viaje al mundo real lo pone todo patas arriba.',
    ageRating: '+12',
    score: 7.0,
    duration: '1 h 54 min',
    genres: ['Comedia', 'Fantasía'],
    schedules: ['13:00', '15:45', '18:30'],
  },
  {
    id: 'fellowship',
    title: 'El Señor de los Anillos',
    poster: '/posters/fellowship.svg',
    synopsis:
      'Un hobbit hereda un anillo mágico y emprende un viaje para destruirlo en las tierras de Mordor.',
    ageRating: '+12',
    score: 8.9,
    duration: '2 h 58 min',
    genres: ['Fantasía', 'Aventura'],
    schedules: ['14:00', '19:00'],
  },
]

export const featuredMovie = movies.find((movie) => movie.featured) ?? movies[0]
